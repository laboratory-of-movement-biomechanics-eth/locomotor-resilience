function [minNormVector,DataPhaseAngleRS] = fct_ellipse2dataNorm(phaseAngleRef,DataPhaseAngleRS,Original,OriginalS,Delayed1S,Delayed2S,...
    ellipse3d,NewxpPre,NewypPre,NewzpPre,resolution2,resolution3,gamma,maxDeviationellipse,normalVector)

%Find the closest point on ellipse to each data point
%
%Input:
%   phaseAngleRef       - Vector with resolution3 number of phase angles
%   DataPhaseAngleRS    - Matrix with info on each datapoint:
%                         [OriginalS, DelayedS1, DelayedS2, PhaseAngleRS, zeros(length(OriginalS),7)]
%   Original            - Vector containing complete dataset of "x-axis"
%   OriginalS           - Vector containing complete sorted dataset of "x-axis"
%   Delayed1S           - Vector containing complete sorted dataset of "y-axis"
%   Delayed2S           - Vector containing complete sorted dataset of "z-axis"
%   ellipse3d           - Matrix with resolution3 number of ellipse points and 
%                         ellipse coordinates in the form: [ X Y Z ] ->
%                         (length(resolution3),3*length(OriginalS))
%   NewxpPre            - Vector with Values of fitted reference trajectory
%                         for each phase angle, x-axis
%   NewypPre            - Vector with Values of fitted reference trajectory
%                         for each phase angle, y-axis
%   NewzpPre            - Vector with Values of fitted reference trajectory
%                         for each phase angle, z-axis
%   resolution2         - resolution for splitting phaseangles
%   resolution3         - resolution for splitting ellipses
%   gamma               - ????????????????????????????????????
%   maxDeviationellipse - ellipse with max deviation (:,1) and coordinates
%                         (:,1:3) of point furthest away from reference
%                         trajectory
%   normalvector        - Vector with coordinates at every phaseangle on
%                         reference trajectory pointing in the direction of
%                         the next phaseangle reference trajectory point 
%
% Output:
%   minNormVector       - Vector with coordinates and minimal distance from
%                         every datapoint to ellipse point and coordinates
%                         of the closest point on ellipse: [x,y,z, minNorm]
%   DataPhaseAngleRS    - Matrix with info on each datapoint:
%                         [OriginalS, DelayedS1, DelayedS2, PhaseAngleRS, (:,5:7)]
%                         (:,5) distance from reference trajectory to datapoint
%                         (:,6) angle between maxDevPoint on ellipse & datapoint
%                         (:,7:9) vector normal to ellipse plane (??)
%                         (:,10) y-axis distance from reftraj to datapoint
%                         (:,11) x-axis distance from reftraj to datapoint
%
% Contributed authors: Ravi Deepak (depakroshanblu@gmail.com), Marc Bartholet, Caroline Heimhofer
% Affiliation: Laboratory of Movement Biomechanics, ETH Zurich, Switzerland
% Last Modified: June 2019


k = 1;
j = 1;
normVector = zeros(length(Original),length(phaseAngleRef));
minNormVector = zeros(length(Original),4);
Idx5 = zeros(1, length(Original));
for i = 1:length(Original)
    if phaseAngleRef(k) == DataPhaseAngleRS(i,4)   
        for m = 1:resolution3     
            dataPoint = [OriginalS(i)-NewxpPre(k), Delayed1S(i)-NewypPre(k), Delayed2S(i)-NewzpPre(k)];
            ellipsePoint = [ellipse3d(m,j)-NewxpPre(k), ellipse3d(m,j+1)-NewypPre(k),...
                ellipse3d(m,j+2)-NewzpPre(k)];
            normVector(i,m) = norm(ellipsePoint-dataPoint);
            [minNormVector(i,4), Idx5(i)] = min(normVector(i,1:m));
        end
        minNormVector(i,1:3) = ellipse3d(Idx5(i),j:j+2);
        DataPhaseAngleRS(i,5) = norm(dataPoint);
        maxDevPoint = [maxDeviationellipse(k,1)-NewxpPre(k),maxDeviationellipse(k,2)-NewypPre(k),maxDeviationellipse(k,3)-NewzpPre(k)];
        dataPoint = [OriginalS(i)-NewxpPre(k), Delayed1S(i)-NewypPre(k), Delayed2S(i)-NewzpPre(k)];
        normmaxDevPoint = norm(maxDevPoint);
        normminNormPoint = norm(dataPoint);
        if gamma(k) == 1
            DataPhaseAngleRS(i,6) = acosd(dot(maxDevPoint,dataPoint)/(normmaxDevPoint*normminNormPoint));
        elseif gamma(k) == 0
            maxDevPoint = -maxDevPoint;
            DataPhaseAngleRS(i,6) = acosd(dot(maxDevPoint,dataPoint)/(normmaxDevPoint*normminNormPoint));
        end
        
        DataPhaseAngleRS(i,7:9) = cross(maxDevPoint,dataPoint);
        if sign(DataPhaseAngleRS(i,7)) == sign(normalVector(k,1)) && ...
                sign(DataPhaseAngleRS(i,8)) == sign(normalVector(k,2)) && ...
                sign(DataPhaseAngleRS(i,9)) == sign(normalVector(k,3))
            DataPhaseAngleRS(i,6) = DataPhaseAngleRS(i,6) + 180;
        end
        
        DataPhaseAngleRS(i,10) = sind(DataPhaseAngleRS(i,6)) * DataPhaseAngleRS(i,5);
        DataPhaseAngleRS(i,11) = cosd(DataPhaseAngleRS(i,6)) * DataPhaseAngleRS(i,5);

    elseif DataPhaseAngleRS(i,4) == 360
        for m = 1:resolution3
            j = 1;
            k = 1;
            dataPoint = [OriginalS(i)-NewxpPre(k), Delayed1S(i)-NewypPre(k), Delayed2S(i)-NewzpPre(k)];
            ellipsePoint = [ellipse3d(m,j)-NewxpPre(k), ellipse3d(m,j+1)-NewypPre(k),...
                ellipse3d(m,j+2)-NewzpPre(k)];
            normVector(i,m) = norm(ellipsePoint-dataPoint);
            [minNormVector(i,4), Idx5(i)] = min(normVector(i,1:m));
        end
        minNormVector(i,1:3) = ellipse3d(Idx5(i),j:j+2);
        DataPhaseAngleRS(i,5) = norm(dataPoint);
        maxDevPoint = [maxDeviationellipse(k,1)-NewxpPre(k),maxDeviationellipse(k,2)-NewypPre(k),maxDeviationellipse(k,3)-NewzpPre(k)];
        dataPoint = [OriginalS(i)-NewxpPre(k), Delayed1S(i)-NewypPre(k), Delayed2S(i)-NewzpPre(k)];
        normmaxDevPoint = norm(maxDevPoint);
        normminNormPoint = norm(dataPoint);
        if gamma(k) == 1
            DataPhaseAngleRS(i,6) = acosd(dot(maxDevPoint,dataPoint)/(normmaxDevPoint*normminNormPoint));
        elseif gamma(k) == 0
            maxDevPoint = -maxDevPoint;
            DataPhaseAngleRS(i,6) = acosd(dot(maxDevPoint,dataPoint)/(normmaxDevPoint*normminNormPoint));
        end
        
        DataPhaseAngleRS(i,7:9) = cross(maxDevPoint,dataPoint);
        if sign(DataPhaseAngleRS(i,7)) == sign(normalVector(k,1)) && ...
                sign(DataPhaseAngleRS(i,8)) == sign(normalVector(k,2)) && ...
                sign(DataPhaseAngleRS(i,9)) == sign(normalVector(k,3))
            DataPhaseAngleRS(i,6) = DataPhaseAngleRS(i,6) + 180;
        end
        
        DataPhaseAngleRS(i,10) = sind(DataPhaseAngleRS(i,6)) * DataPhaseAngleRS(i,5);
        DataPhaseAngleRS(i,11) = cosd(DataPhaseAngleRS(i,6)) * DataPhaseAngleRS(i,5);
            
        continue;

    else
        if k == resolution2 || j == (resolution2*3)
            for m = 1:resolution3
                dataPoint = [OriginalS(i)-NewxpPre(k), Delayed1S(i)-NewypPre(k), Delayed2S(i)-NewzpPre(k)];
                ellipsePoint = [ellipse3d(m,j)-NewxpPre(k), ellipse3d(m,j+1)-NewypPre(k),...
                    ellipse3d(m,j+2)-NewzpPre(k)];
                normVector(i,m) = norm(ellipsePoint-dataPoint);
                [minNormVector(i,4), Idx5(i)] = min(normVector(i,1:m));
                
            end
            minNormVector(i,1:3) = ellipse3d(Idx5(i),j:j+2);
            DataPhaseAngleRS(i,5) = norm(dataPoint);
            maxDevPoint = [maxDeviationellipse(k,1)-NewxpPre(k),maxDeviationellipse(k,2)-NewypPre(k),maxDeviationellipse(k,3)-NewzpPre(k)];
            dataPoint = [OriginalS(i)-NewxpPre(k), Delayed1S(i)-NewypPre(k), Delayed2S(i)-NewzpPre(k)];
            normmaxDevPoint = norm(maxDevPoint);
            normminNormPoint = norm(dataPoint);
            if gamma(k) == 1
                DataPhaseAngleRS(i,6) = acosd(dot(maxDevPoint,dataPoint)/(normmaxDevPoint*normminNormPoint));
            elseif gamma(k) == 0
                maxDevPoint = -maxDevPoint;
                DataPhaseAngleRS(i,6) = acosd(dot(maxDevPoint,dataPoint)/(normmaxDevPoint*normminNormPoint));
            end
            
            DataPhaseAngleRS(i,7:9) = cross(maxDevPoint,dataPoint);
            if sign(DataPhaseAngleRS(i,7)) == sign(normalVector(k,1)) && ...
                    sign(DataPhaseAngleRS(i,8)) == sign(normalVector(k,2)) && ...
                    sign(DataPhaseAngleRS(i,9)) == sign(normalVector(k,3))
                DataPhaseAngleRS(i,6) = DataPhaseAngleRS(i,6) + 180;
            end
            
            DataPhaseAngleRS(i,10) = sind(DataPhaseAngleRS(i,6)) * DataPhaseAngleRS(i,5);
            DataPhaseAngleRS(i,11) = cosd(DataPhaseAngleRS(i,6)) * DataPhaseAngleRS(i,5);
            
            break;
        else
            k = k + 1;
            j = j + 3;
            
            for k = k:resolution2
                if phaseAngleRef(k) == DataPhaseAngleRS(i,4)
                    j = (k - 1) * 3 + 1;
                    for m = 1:resolution3
                        dataPoint = [OriginalS(i)-NewxpPre(k), Delayed1S(i)-NewypPre(k), Delayed2S(i)-NewzpPre(k)];
                        ellipsePoint = [ellipse3d(m,j)-NewxpPre(k), ellipse3d(m,j+1)-NewypPre(k),...
                            ellipse3d(m,j+2)-NewzpPre(k)];
                        normVector(i,m) = norm(ellipsePoint-dataPoint);
                        [minNormVector(i,4), Idx5(i)] = min(normVector(i,1:m));
                    end
                    minNormVector(i,1:3) = ellipse3d(Idx5(i),j:j+2);
                    DataPhaseAngleRS(i,5) = norm(dataPoint);
                    maxDevPoint = [maxDeviationellipse(k,1)-NewxpPre(k),maxDeviationellipse(k,2)-NewypPre(k),maxDeviationellipse(k,3)-NewzpPre(k)];
                    dataPoint = [OriginalS(i)-NewxpPre(k), Delayed1S(i)-NewypPre(k), Delayed2S(i)-NewzpPre(k)];
                    normmaxDevPoint = norm(maxDevPoint);
                    normminNormPoint = norm(dataPoint);
                    if gamma(k) == 1
                        DataPhaseAngleRS(i,6) = acosd(dot(maxDevPoint,dataPoint)/(normmaxDevPoint*normminNormPoint));
                    elseif gamma(k) == 0
                        maxDevPoint = -maxDevPoint;
                        DataPhaseAngleRS(i,6) = acosd(dot(maxDevPoint,dataPoint)/(normmaxDevPoint*normminNormPoint));
                    end
                    
                    DataPhaseAngleRS(i,7:9) = cross(maxDevPoint,dataPoint);
                    if sign(DataPhaseAngleRS(i,7)) == sign(normalVector(k,1)) && ...
                            sign(DataPhaseAngleRS(i,8)) == sign(normalVector(k,2)) && ...
                            sign(DataPhaseAngleRS(i,9)) == sign(normalVector(k,3))
                        DataPhaseAngleRS(i,6) = DataPhaseAngleRS(i,6) + 180;
                    end
                    
                    DataPhaseAngleRS(i,10) = sind(DataPhaseAngleRS(i,6)) * DataPhaseAngleRS(i,5);
                    DataPhaseAngleRS(i,11) = cosd(DataPhaseAngleRS(i,6)) * DataPhaseAngleRS(i,5);
                    
                    break;
                end
            end
        end   
    end
end
end

