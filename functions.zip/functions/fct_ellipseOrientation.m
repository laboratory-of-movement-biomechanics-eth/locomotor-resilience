function [ellipse3d,maxDeviationellipse,maxDeviationProj,axisOrientation] = fct_ellipseOrientation(ellipse3d,NewxpPre,NewypPre,NewzpPre,...
    resolution2,resolution3,normalVector,maxDeviation)
% Orient ellipse so major axis is oriented towards the furthest point of
% the data
%
%Input:
%   ellipse3d           - Matrix with resolution3 number of ellipse points and 
%                         ellipse coordinates in the form: [ X Y Z ] ->
%                         (length(resolution3),3*length(OriginalS))
%   NewxpPre            - Vector with Values of fitted reference trajectory
%                         for each phase angle, x-axis
%   NewypPre            - Vector with Values of fitted reference trajectory
%                         for each phase angle, y-axis
%   NewzpPre            - Vector with Values of fitted reference trajectory
%                         for each phase angle, z-axis
%   resolution2         - resolution for splitting phaseangles
%   resolution3         - resolution for splitting ellipses
%   normalvector        - Vector with coordinates at every phaseangle on
%                         reference trajectory pointing in the direction of
%                         the next phaseangle reference trajectory point 
%   maxDeviation       - Matrix of data points with max deviation from
%                        reference trajectory for every phase angle
%                        (:,1:3) - coordinates of points
%                        (:,4)   - max deviation
%                        (:,5)   - second max deviation

%
% Output:
%   ellipse3d           - Matrix with resolution3 number of ellipse points and 
%                         ellipse coordinates in the form: [ X Y Z ] ->
%                         (length(resolution3),3*length(OriginalS)),
%                         rotated and aligned with furthest point of data
%   maxDeviationellipse - ellipse with max deviation (:,1) and coordinates
%                         (:,1:3) of point furthest away from reference
%                         trajectory]
%   maxDeviationProj    - Matrix with projection of max deviation point
%                         onto ellipse
%   axisOrientation     - Vector for every phase angle with 
%                         1 if normal vector and vector of projected
%                           datapoint (with max deviation onto ellipse)
%                           point in same direction
%                         0 if vectors do not point in same direction
%
% Contributed authors: Ravi Deepak (depakroshanblu@gmail.com), Marc Bartholet, Caroline Heimhofer
% Affiliation: Laboratory of Movement Biomechanics, ETH Zurich, Switzerland
% Last Modified: June 2019



% Projection of maxDeviation points on ellipse plane
maxDeviationProj = zeros(length(resolution2),3);
for i = 1:resolution2
    d = planeD(normalVector(i,1),normalVector(i,2),normalVector(i,3),...
            NewxpPre(i),NewypPre(i),NewzpPre(i));
    [maxDeviationProj(i,1),maxDeviationProj(i,2),maxDeviationProj(i,3)] = ...
            projection(normalVector(i,1),normalVector(i,2),normalVector(i,3),...
            d,maxDeviation(i,1),maxDeviation(i,2),maxDeviation(i,3));
end

% Find deviation maxima of ellipse to reference trajectory
deviationellipse = zeros(resolution3, resolution2);
maxDeviationellipse = zeros(resolution2,4);
Idx3 = zeros(resolution2,1);
j = 1;
for i = 1:resolution2
    for m = 1:resolution3
        deviationellipse(m,i) = norm([ellipse3d(m,j)-NewxpPre(i), ellipse3d(m,j+1)-NewypPre(i), ellipse3d(m,j+2)-NewzpPre(i)]);
        [maxDeviationellipse(i,4), Idx3(i)] = max(deviationellipse(1:m,i));
        maxDeviationellipse(i,1:3) = ellipse3d(Idx3(i),j:j+2);
    end
    j = j + 3;
end

% Create rotation matrices between the maxima deviatiation of ellipse and
% the maxima of state space around the refernce trajectory!!!
j=1;
rotationVector2 = zeros(length(resolution2), 4);
axisOrientation = zeros(length(resolution2));
for i = 1:resolution2
    if i == resolution2 
        ellipsePoint = [maxDeviationellipse(resolution2,1) - NewxpPre(resolution2),...
            maxDeviationellipse(resolution2,2) - NewypPre(resolution2),maxDeviationellipse(resolution2,3) - NewzpPre(resolution2)];
        normEllipse = norm(ellipsePoint);
        dataPoint = [maxDeviationProj(resolution2,1) - NewxpPre(resolution2),...
            maxDeviationProj(resolution2,2) - NewypPre(resolution2),maxDeviationProj(resolution2,3) - NewzpPre(resolution2)];
        normData = norm(dataPoint);
        rotationVector2(resolution2,4) = acos(dot(dataPoint,ellipsePoint) / (normData * normEllipse));
        rotationVector2(resolution2,1:3) = cross(dataPoint,ellipsePoint);
        rotationVector2(resolution2,1:3) = rotationVector2(resolution2,1:3) / norm(rotationVector2(resolution2,1:3));
        
        if sign(rotationVector2(resolution2,1)) == sign(normalVector(resolution2,1)) && ...
                sign(rotationVector2(resolution2,2)) == sign(normalVector(resolution2,2)) && ...
                sign(rotationVector2(resolution2,3)) == sign(normalVector(resolution2,3))
        
            rotationMatrix2(:,(resolution2*3-2):(resolution2*3)) = rotationVectorToMatrix(rotationVector2(resolution2,4)*...
                [-normalVector(resolution2,1),-normalVector(resolution2,2),-normalVector(resolution2,3)]); 
            axisOrientation(i) = 1;
        else
            rotationMatrix2(:,(resolution2*3-2):(resolution2*3)) = rotationVectorToMatrix(rotationVector2(resolution2,4)*...
                [normalVector(resolution2,1),normalVector(resolution2,2),normalVector(resolution2,3)]);
            axisOrientation(i) = 0;
        end

        break;

    else
        ellipsePoint = [maxDeviationellipse(i,1) - NewxpPre(i),...
            maxDeviationellipse(i,2) - NewypPre(i),maxDeviationellipse(i,3) - NewzpPre(i)];
        normEllipse = norm(ellipsePoint);
        dataPoint = [maxDeviationProj(i,1) - NewxpPre(i),...
            maxDeviationProj(i,2) - NewypPre(i),maxDeviationProj(i,3) - NewzpPre(i)];
        normData = norm(dataPoint);
        rotationVector2(i,4) = acos(dot(dataPoint,ellipsePoint) / (normData * normEllipse));
        rotationVector2(i,1:3) = cross(dataPoint,ellipsePoint);
        rotationVector2(i,1:3) = rotationVector2(i,1:3) / norm(rotationVector2(i,1:3));
        
        if sign(rotationVector2(i,1)) == sign(normalVector(i,1)) && ...
                sign(rotationVector2(i,2)) == sign(normalVector(i,2)) && ...
                sign(rotationVector2(i,3)) == sign(normalVector(i,3))
        
            rotationMatrix2(:,j:j+2) = rotationVectorToMatrix(rotationVector2(i,4)*...
                [-normalVector(i,1),-normalVector(i,2),-normalVector(i,3)]); 
            axisOrientation(i) = 1;
        else
            rotationMatrix2(:,j:j+2) = rotationVectorToMatrix(rotationVector2(i,4)*...
                [normalVector(i,1),normalVector(i,2),normalVector(i,3)]);
            axisOrientation(i) = 0;
        end
        
    end
    j = j + 3;
end



% Rotate the ellipse around reference trajectory
j = 1;
for i = 1:resolution2
    if j > (resolution2*3)
        break;
    else
        for m = 1:resolution3
            ellipse3d(m,j) = ellipse3d(m,j) - NewxpPre(i);
            ellipse3d(m,j+1) = ellipse3d(m,j+1) - NewypPre(i);
            ellipse3d(m,j+2) = ellipse3d(m,j+2) - NewzpPre(i);
            
            ellipse3d(m,j:j+2) = ellipse3d(m,j:j+2)  * rotationMatrix2(:,j:j+2);
            
            ellipse3d(m,j) = ellipse3d(m,j) + NewxpPre(i);
            ellipse3d(m,j+1) = ellipse3d(m,j+1) + NewypPre(i);
            ellipse3d(m,j+2) = ellipse3d(m,j+2) + NewzpPre(i);
        end
        j = j + 3;
    end
end


j = 1;
for i = 1:resolution2
    for m = 1:resolution3
        deviationellipse(m,i) = norm([ellipse3d(m,j)-NewxpPre(i), ellipse3d(m,j+1)-NewypPre(i), ellipse3d(m,j+2)-NewzpPre(i)]);
        [maxDeviationellipse(i,4), Idx3(i)] = max(deviationellipse(1:m,i));
        maxDeviationellipse(i,1:3) = ellipse3d(Idx3(i),j:j+2);
    end
    j = j + 3;
end

end

