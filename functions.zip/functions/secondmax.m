function [y] = secondmax(x)
   y = max(x(x<max(x)));
end
