function [stabilityVector_01,stabilityVector_01_02,instabilityVector_02_03,instabilityVector_03,stabilityVector,instabilityVectorTube,...
    instabilityVector,instabilityVectorPct,stabilityVector1,instabilityVector1,stabilityVector1Tube,instabilityVector1Tube,...
    instabilityVectorTubePct,stabilityVectorSum] = ...
    fct_stability02(Idx4,phaseAngleRef,DataPhaseAngleRS,PreOriginal,Original,OriginalS,Delayed1S,Delayed2S,NewxpPre,NewypPre,NewzpPre,...
    minNormVector02,minNormVector01,minNormVector03,resolution2,resolution4)

%stable is defined as 'inside 2nd std'
%Input:
%   Idx4             - Indices of how to sort phaseangles
%   phaseAngleRef    - Vector with resolution3 number of phase angles
%   DataPhaseAngleRS - Matrix with info on each datapoint:
%                       [OriginalS, DelayedS1, DelayedS2, PhaseAngleRS, (:,5:7)]
%                       (:,5) distance from reference trajectory to datapoint
%                       (:,6) angle between maxDevPoint on ellipse & datapoint
%                       (:,7:9) vector normal to ellipse plane (??)
%                       (:,10) y-axis distance from reftraj to datapoint
%                       (:,11) x-axis distance from reftraj to datapoint
%   PreOriginal/Original         - Vector containing pre-perturbation/complete 
%                                   dataset of "x-axis"
%   OriginalS/Delayed1S/Delayed2S- Vector containing complete sorted 
%                                   dataset of "x/y/z-axis"
%   NewxpPre/NewypPre/NewzpPre   - Vector with Values of fitted reference
%                                   trajectory for each phase angle
%   minNormVector    - Vector with coordinates and minimal distance from
%                      every datapoint to ellipse point and coordinates
%                      of the closest point on ellipse: [x,y,z, minNorm]
%   resolution2      - resolution for splitting phaseangles
%   resolution4      - constant....???????????????????????????????????????????
%
% Output:
%  stabilityVector_01       - Vector with distance of RefTraj to points if closer to RefTraj than 1st std ellipse, otherwise nan
%  stabilityVector_01_02    - Vector with distance of RefTraj to points if lying between 1st and 2nd std ellipse, otherwise nan
%  instabilityVector_02_03  - Vector with distance of RefTraj to points if lying between 2nd and 3rd std ellipse, otherwise nan
%  instabilityVector_03     - Vector with distance of RefTraj to points if lying outside 3rd std ellipse, otherwise nan
%  stabilityVector          - Vector with 1 if "stable"(i.e. inside 2nd std) and 0 if "instable"
%  instabilityVectorTube    - Vector with distance from 2nd std ellipse to every datapoint
%  instabilityVector        - Vector with distance from datapoint to refTraj for every point
%  stabilityVector1         - Vector with distance of RefTraj to points if "stable" (i.e. inside 2nd std), otherwise nan
%  instabilityVector1       - Vector with distance of RefTraj to points if "instable" (i.e. outside 2nd std), otherwise nan
%  stabilityVector1Tube     - Vector with distance from 2nd std ellipse to every datapoint if "stable" (i.e. inside 2nd std), otherwise nan
%  instabilityVector1Tube   - Vector with distance from 2nd std ellipse to every datapoint if "instable" (i.e. outside 2nd std), otherwise nan
%  instabilityVectorTubePct - Rate of distances ellipse to point : ellipse to ref traj for instable points (i.e. outside 3rd std), otherwise 0
%  instabilityVectorPct     - Normed instabilityVector
%  stabilityVectorSum       - Number of "stable"(i.e. inside 2nd std)pre-perturbed datapoints

%
% Contributed authors: Ravi Deepak (depakroshanblu@gmail.com), Marc Bartholet, Caroline Heimhofer
% Affiliation: Laboratory of Movement Biomechanics, ETH Zurich, Switzerland
% Last Modified: June 2019

stabilityVector_01 = zeros(length(Original),1);
stabilityVector_01_02 = zeros(length(Original),1);
instabilityVector_02_03 = zeros(length(Original),1);
instabilityVector_03 = zeros(length(Original),1);

stabilityVector = zeros(length(Original),1);
instabilityVectorTube = zeros(length(Original),1);
instabilityVector = zeros(length(Original),1);
stabilityVector1 = zeros(length(Original),1);
instabilityVector1 = zeros(length(Original),1);
stabilityVector1Tube = zeros(length(Original),1);
instabilityVector1Tube = zeros(length(Original),1);
instabilityVectorTubePct = zeros(length(Original),1);
instabilityVectorPct = zeros(length(Original),1);


k = 1;
j = 1;
for i = 1:length(Original)
%     if i == 23786
%         fprintf('\b');
%     end
    if phaseAngleRef(k) == DataPhaseAngleRS(i,4)
        
        instabilityVector(i) = norm([OriginalS(i)-NewxpPre(k), Delayed1S(i)-NewypPre(k), Delayed2S(i)-NewzpPre(k)]);
        instabilityVectorTube(i) = norm([OriginalS(i)-minNormVector02(i,1), Delayed1S(i)-minNormVector02(i,2),...
                Delayed2S(i)-minNormVector02(i,3)]);
        instabilityVectorPct(i) = norm([OriginalS(i)-minNormVector02(i,1), Delayed1S(i)-minNormVector02(i,2),...
            Delayed2S(i)-minNormVector02(i,3)]) / norm([minNormVector02(i,1)-NewxpPre(k), ...
            minNormVector02(i,2)-NewypPre(k),minNormVector02(i,3)-NewzpPre(k)]);

        
        if norm([OriginalS(i)-NewxpPre(k), Delayed1S(i)-NewypPre(k), Delayed2S(i)-NewzpPre(k)])...
                <= resolution4*(norm([minNormVector01(i,1)-NewxpPre(k),minNormVector01(i,2)-NewypPre(k),minNormVector01(i,3)-NewzpPre(k)]))
            % stable 
            stabilityVector(i) = 1;
            stabilityVector1(i) = norm([OriginalS(i)-NewxpPre(k), Delayed1S(i)-NewypPre(k), Delayed2S(i)-NewzpPre(k)]);
            instabilityVector1(i) = nan;
            
            stabilityVector_01(i) = norm([OriginalS(i)-NewxpPre(k), Delayed1S(i)-NewypPre(k), Delayed2S(i)-NewzpPre(k)]);
            stabilityVector_01_02(i) = nan;
            instabilityVector_02_03(i) = nan;
            instabilityVector_03(i) = nan;
            
            stabilityVector1Tube(i) = norm([OriginalS(i)-minNormVector02(i,1), Delayed1S(i)-minNormVector02(i,2),...
                Delayed2S(i)-minNormVector02(i,3)]);
            instabilityVector1Tube(i) = nan;
            
            instabilityVectorTubePct(i) = 0;
            
        elseif norm([OriginalS(i)-NewxpPre(k), Delayed1S(i)-NewypPre(k), Delayed2S(i)-NewzpPre(k)])...
                > resolution4*(norm([minNormVector01(i,1)-NewxpPre(k),minNormVector01(i,2)-NewypPre(k),minNormVector01(i,3)-NewzpPre(k)])) && ...
                norm([OriginalS(i)-NewxpPre(k), Delayed1S(i)-NewypPre(k), Delayed2S(i)-NewzpPre(k)])...
                <= resolution4*(norm([minNormVector02(i,1)-NewxpPre(k),minNormVector02(i,2)-NewypPre(k),minNormVector02(i,3)-NewzpPre(k)]))
            
            % stable
            stabilityVector(i) = 1;
            stabilityVector1(i) = norm([OriginalS(i)-NewxpPre(k), Delayed1S(i)-NewypPre(k), Delayed2S(i)-NewzpPre(k)]);
            instabilityVector1(i) = nan;
            
            stabilityVector_01(i) = nan;
            stabilityVector_01_02(i) = norm([OriginalS(i)-NewxpPre(k), Delayed1S(i)-NewypPre(k), Delayed2S(i)-NewzpPre(k)]);
            instabilityVector_02_03(i) = nan;
            instabilityVector_03(i) = nan;
            
            stabilityVector1Tube(i) = norm([OriginalS(i)-minNormVector02(i,1), Delayed1S(i)-minNormVector02(i,2),...
                Delayed2S(i)-minNormVector02(i,3)]);
            instabilityVector1Tube(i) = nan;
            
            instabilityVectorTubePct(i) = 0 ;
            
        elseif norm([OriginalS(i)-NewxpPre(k), Delayed1S(i)-NewypPre(k), Delayed2S(i)-NewzpPre(k)])...
                > resolution4*(norm([minNormVector02(i,1)-NewxpPre(k),minNormVector02(i,2)-NewypPre(k),minNormVector02(i,3)-NewzpPre(k)])) && ...
                norm([OriginalS(i)-NewxpPre(k), Delayed1S(i)-NewypPre(k), Delayed2S(i)-NewzpPre(k)])...
                <= resolution4*(norm([minNormVector03(i,1)-NewxpPre(k),minNormVector03(i,2)-NewypPre(k),minNormVector03(i,3)-NewzpPre(k)]))
            
            % unstable
            stabilityVector(i) = 0;
            stabilityVector1(i) = nan;
            instabilityVector1(i) = norm([OriginalS(i)-NewxpPre(k), Delayed1S(i)-NewypPre(k), Delayed2S(i)-NewzpPre(k)]);
            
            stabilityVector_01(i) = nan;
            stabilityVector_01_02(i) = nan;
            instabilityVector_02_03(i) = norm([OriginalS(i)-NewxpPre(k), Delayed1S(i)-NewypPre(k), Delayed2S(i)-NewzpPre(k)]);
            instabilityVector_03(i) = nan;
            
            stabilityVector1Tube(i) = nan;
            instabilityVector1Tube(i) = norm([OriginalS(i)-minNormVector02(i,1), Delayed1S(i)-minNormVector02(i,2),...
                Delayed2S(i)-minNormVector02(i,3)]);
            
            instabilityVectorTubePct(i) = instabilityVector1Tube(i) / norm([minNormVector02(i,1)-NewxpPre(k), ...
                minNormVector02(i,2)-NewypPre(k),minNormVector02(i,3)-NewzpPre(k)]);
            
            

        elseif  norm([OriginalS(i)-NewxpPre(k), Delayed1S(i)-NewypPre(k), Delayed2S(i)-NewzpPre(k)])...
                > resolution4*(norm([minNormVector03(i,1)-NewxpPre(k),minNormVector03(i,2)-NewypPre(k),minNormVector03(i,3)-NewzpPre(k)]))
            
            % unstable
            stabilityVector(i) = 0;
            stabilityVector1(i) = nan;
            instabilityVector1(i) = norm([OriginalS(i)-NewxpPre(k), Delayed1S(i)-NewypPre(k), Delayed2S(i)-NewzpPre(k)]);
            
            stabilityVector_01(i) = nan;
            stabilityVector_01_02(i) = nan;
            instabilityVector_02_03(i) = nan;
            instabilityVector_03(i) = norm([OriginalS(i)-NewxpPre(k), Delayed1S(i)-NewypPre(k), Delayed2S(i)-NewzpPre(k)]);
            
            stabilityVector1Tube(i) = nan;
            instabilityVector1Tube(i) = norm([OriginalS(i)-minNormVector02(i,1), Delayed1S(i)-minNormVector02(i,2),...
                Delayed2S(i)-minNormVector02(i,3)]);
            
            instabilityVectorTubePct(i) = instabilityVector1Tube(i) / norm([minNormVector02(i,1)-NewxpPre(k), ...
                minNormVector02(i,2)-NewypPre(k),minNormVector02(i,3)-NewzpPre(k)]);
        end  
        
    elseif DataPhaseAngleRS(i,4) == 360
        j = 1;
        instabilityVector(i) = norm([OriginalS(i)-NewxpPre(k), Delayed1S(i)-NewypPre(k), Delayed2S(i)-NewzpPre(k)]);
        instabilityVectorTube(i) = norm([OriginalS(i)-minNormVector02(i,1), Delayed1S(i)-minNormVector02(i,2),...
                Delayed2S(i)-minNormVector02(i,3)]);
        instabilityVectorPct(i) = norm([OriginalS(i)-minNormVector02(i,1), Delayed1S(i)-minNormVector02(i,2),...
            Delayed2S(i)-minNormVector02(i,3)]) / norm([minNormVector02(i,1)-NewxpPre(k), ...
            minNormVector02(i,2)-NewypPre(k),minNormVector02(i,3)-NewzpPre(k)]);

        if norm([OriginalS(i)-NewxpPre(k), Delayed1S(i)-NewypPre(k), Delayed2S(i)-NewzpPre(k)])...
                <= resolution4*(norm([minNormVector01(i,1)-NewxpPre(k),minNormVector01(i,2)-NewypPre(k),minNormVector01(i,3)-NewzpPre(k)]))
            % stable 
            stabilityVector(i) = 1;
            stabilityVector1(i) = norm([OriginalS(i)-NewxpPre(k), Delayed1S(i)-NewypPre(k), Delayed2S(i)-NewzpPre(k)]);
            instabilityVector1(i) = nan;
            
            stabilityVector_01(i) = norm([OriginalS(i)-NewxpPre(k), Delayed1S(i)-NewypPre(k), Delayed2S(i)-NewzpPre(k)]);
            stabilityVector_01_02(i) = nan;
            instabilityVector_02_03(i) = nan;
            instabilityVector_03(i) = nan;
            
            stabilityVector1Tube(i) = norm([OriginalS(i)-minNormVector02(i,1), Delayed1S(i)-minNormVector02(i,2),...
                Delayed2S(i)-minNormVector02(i,3)]);
            instabilityVector1Tube(i) = nan;
            
            instabilityVectorTubePct(i) = 0;
            
        elseif norm([OriginalS(i)-NewxpPre(k), Delayed1S(i)-NewypPre(k), Delayed2S(i)-NewzpPre(k)])...
                > resolution4*(norm([minNormVector01(i,1)-NewxpPre(k),minNormVector01(i,2)-NewypPre(k),minNormVector01(i,3)-NewzpPre(k)])) && ...
                norm([OriginalS(i)-NewxpPre(k), Delayed1S(i)-NewypPre(k), Delayed2S(i)-NewzpPre(k)])...
                <= resolution4*(norm([minNormVector02(i,1)-NewxpPre(k),minNormVector02(i,2)-NewypPre(k),minNormVector02(i,3)-NewzpPre(k)]))
            
            % stable
            stabilityVector(i) = 1;
            stabilityVector1(i) = norm([OriginalS(i)-NewxpPre(k), Delayed1S(i)-NewypPre(k), Delayed2S(i)-NewzpPre(k)]);
            instabilityVector1(i) = nan;
            
            stabilityVector_01(i) = nan;
            stabilityVector_01_02(i) = norm([OriginalS(i)-NewxpPre(k), Delayed1S(i)-NewypPre(k), Delayed2S(i)-NewzpPre(k)]);
            instabilityVector_02_03(i) = nan;
            instabilityVector_03(i) = nan;
            
            stabilityVector1Tube(i) = norm([OriginalS(i)-minNormVector02(i,1), Delayed1S(i)-minNormVector02(i,2),...
                Delayed2S(i)-minNormVector02(i,3)]);
            instabilityVector1Tube(i) = nan;
            
            instabilityVectorTubePct(i) = 0 ;
            
        elseif norm([OriginalS(i)-NewxpPre(k), Delayed1S(i)-NewypPre(k), Delayed2S(i)-NewzpPre(k)])...
                > resolution4*(norm([minNormVector02(i,1)-NewxpPre(k),minNormVector02(i,2)-NewypPre(k),minNormVector02(i,3)-NewzpPre(k)])) && ...
                norm([OriginalS(i)-NewxpPre(k), Delayed1S(i)-NewypPre(k), Delayed2S(i)-NewzpPre(k)])...
                <= resolution4*(norm([minNormVector03(i,1)-NewxpPre(k),minNormVector03(i,2)-NewypPre(k),minNormVector03(i,3)-NewzpPre(k)]))
            
            % unstable
            stabilityVector(i) = 0;
            stabilityVector1(i) = nan;
            instabilityVector1(i) = norm([OriginalS(i)-NewxpPre(k), Delayed1S(i)-NewypPre(k), Delayed2S(i)-NewzpPre(k)]);
            
            stabilityVector_01(i) = nan;
            stabilityVector_01_02(i) = nan;
            instabilityVector_02_03(i) = norm([OriginalS(i)-NewxpPre(k), Delayed1S(i)-NewypPre(k), Delayed2S(i)-NewzpPre(k)]);
            instabilityVector_03(i) = nan;
            
            stabilityVector1Tube(i) = nan;
            instabilityVector1Tube(i) = norm([OriginalS(i)-minNormVector02(i,1), Delayed1S(i)-minNormVector02(i,2),...
                Delayed2S(i)-minNormVector02(i,3)]);
            
            instabilityVectorTubePct(i) = instabilityVector1Tube(i) / norm([minNormVector02(i,1)-NewxpPre(k), ...
                minNormVector02(i,2)-NewypPre(k),minNormVector02(i,3)-NewzpPre(k)]);
            
            

        elseif  norm([OriginalS(i)-NewxpPre(k), Delayed1S(i)-NewypPre(k), Delayed2S(i)-NewzpPre(k)])...
                > resolution4*(norm([minNormVector03(i,1)-NewxpPre(k),minNormVector03(i,2)-NewypPre(k),minNormVector03(i,3)-NewzpPre(k)]))
            
            % unstable
            stabilityVector(i) = 0;
            stabilityVector1(i) = nan;
            instabilityVector1(i) = norm([OriginalS(i)-NewxpPre(k), Delayed1S(i)-NewypPre(k), Delayed2S(i)-NewzpPre(k)]);
            
            stabilityVector_01(i) = nan;
            stabilityVector_01_02(i) = nan;
            instabilityVector_02_03(i) = nan;
            instabilityVector_03(i) = norm([OriginalS(i)-NewxpPre(k), Delayed1S(i)-NewypPre(k), Delayed2S(i)-NewzpPre(k)]);
            
            stabilityVector1Tube(i) = nan;
            instabilityVector1Tube(i) = norm([OriginalS(i)-minNormVector02(i,1), Delayed1S(i)-minNormVector02(i,2),...
                Delayed2S(i)-minNormVector02(i,3)]);
            
            instabilityVectorTubePct(i) = instabilityVector1Tube(i) / norm([minNormVector02(i,1)-NewxpPre(k), ...
                minNormVector02(i,2)-NewypPre(k),minNormVector02(i,3)-NewzpPre(k)]);
        end 
        
    else
        
        instabilityVector(i) = norm([OriginalS(i)-NewxpPre(k), Delayed1S(i)-NewypPre(k), Delayed2S(i)-NewzpPre(k)]);
        instabilityVectorTube(i) = norm([OriginalS(i)-minNormVector02(i,1), Delayed1S(i)-minNormVector02(i,2),...
        Delayed2S(i)-minNormVector02(i,3)]);
        instabilityVectorPct(i) = norm([OriginalS(i)-minNormVector02(i,1), Delayed1S(i)-minNormVector02(i,2),...
                Delayed2S(i)-minNormVector02(i,3)]) / norm([minNormVector02(i,1)-NewxpPre(k), ...
                minNormVector02(i,2)-NewypPre(k),minNormVector02(i,3)-NewzpPre(k)]);

        if norm([OriginalS(i)-NewxpPre(k), Delayed1S(i)-NewypPre(k), Delayed2S(i)-NewzpPre(k)])...
            > resolution4*(norm([minNormVector02(i,1)-NewxpPre(k),minNormVector02(i,2)-NewypPre(k),minNormVector02(i,3)-NewzpPre(k)])) && ...
            norm([OriginalS(i)-NewxpPre(k), Delayed1S(i)-NewypPre(k), Delayed2S(i)-NewzpPre(k)])...
            <= resolution4*(norm([minNormVector03(i,1)-NewxpPre(k),minNormVector03(i,2)-NewypPre(k),minNormVector03(i,3)-NewzpPre(k)]))
            
            % unstable
            stabilityVector(i) = 0;
            stabilityVector1(i) = nan;
            instabilityVector1(i) = norm([OriginalS(i)-NewxpPre(k), Delayed1S(i)-NewypPre(k), Delayed2S(i)-NewzpPre(k)]);
            
            stabilityVector_01(i) = nan;
            stabilityVector_01_02(i) = nan;
            instabilityVector_02_03(i) = norm([OriginalS(i)-NewxpPre(k), Delayed1S(i)-NewypPre(k), Delayed2S(i)-NewzpPre(k)]);
            instabilityVector_03(i) = nan;
            
            stabilityVector1Tube(i) = nan;
            instabilityVector1Tube(i) = norm([OriginalS(i)-minNormVector02(i,1), Delayed1S(i)-minNormVector02(i,2),...
                Delayed2S(i)-minNormVector02(i,3)]);
            
            instabilityVectorTubePct(i) = instabilityVector1Tube(i) / norm([minNormVector02(i,1)-NewxpPre(k), ...
                minNormVector02(i,2)-NewypPre(k),minNormVector02(i,3)-NewzpPre(k)]);
            
            

        elseif  norm([OriginalS(i)-NewxpPre(k), Delayed1S(i)-NewypPre(k), Delayed2S(i)-NewzpPre(k)])...
                > resolution4*(norm([minNormVector03(i,1)-NewxpPre(k),minNormVector03(i,2)-NewypPre(k),minNormVector03(i,3)-NewzpPre(k)]))
            
            % unstable
            stabilityVector(i) = 0;
            stabilityVector1(i) = nan;
            instabilityVector1(i) = norm([OriginalS(i)-NewxpPre(k), Delayed1S(i)-NewypPre(k), Delayed2S(i)-NewzpPre(k)]);
            
            stabilityVector_01(i) = nan;
            stabilityVector_01_02(i) = nan;
            instabilityVector_02_03(i) = nan;
            instabilityVector_03(i) = norm([OriginalS(i)-NewxpPre(k), Delayed1S(i)-NewypPre(k), Delayed2S(i)-NewzpPre(k)]);
            
            stabilityVector1Tube(i) = nan;
            instabilityVector1Tube(i) = norm([OriginalS(i)-minNormVector02(i,1), Delayed1S(i)-minNormVector02(i,2),...
                Delayed2S(i)-minNormVector02(i,3)]);
            
            instabilityVectorTubePct(i) = instabilityVector1Tube(i) / norm([minNormVector02(i,1)-NewxpPre(k), ...
                minNormVector02(i,2)-NewypPre(k),minNormVector02(i,3)-NewzpPre(k)]);
    
        
        else
            if k == resolution2 || j == (resolution2*3)
                if norm([OriginalS(i)-NewxpPre(k), Delayed1S(i)-NewypPre(k), Delayed2S(i)-NewzpPre(k)])...
                <= resolution4*(norm([minNormVector01(i,1)-NewxpPre(k),minNormVector01(i,2)-NewypPre(k),minNormVector01(i,3)-NewzpPre(k)]))
                    % stable 
                    stabilityVector(i) = 1;
                    stabilityVector1(i) = norm([OriginalS(i)-NewxpPre(k), Delayed1S(i)-NewypPre(k), Delayed2S(i)-NewzpPre(k)]);
                    instabilityVector1(i) = nan;

                    stabilityVector_01(i) = norm([OriginalS(i)-NewxpPre(k), Delayed1S(i)-NewypPre(k), Delayed2S(i)-NewzpPre(k)]);
                    stabilityVector_01_02(i) = nan;
                    instabilityVector_02_03(i) = nan;
                    instabilityVector_03(i) = nan;

                    stabilityVector1Tube(i) = norm([OriginalS(i)-minNormVector02(i,1), Delayed1S(i)-minNormVector02(i,2),...
                        Delayed2S(i)-minNormVector02(i,3)]);
                    instabilityVector1Tube(i) = nan;

                    instabilityVectorTubePct(i) = 0;

                elseif norm([OriginalS(i)-NewxpPre(k), Delayed1S(i)-NewypPre(k), Delayed2S(i)-NewzpPre(k)])...
                        > resolution4*(norm([minNormVector01(i,1)-NewxpPre(k),minNormVector01(i,2)-NewypPre(k),minNormVector01(i,3)-NewzpPre(k)])) && ...
                        norm([OriginalS(i)-NewxpPre(k), Delayed1S(i)-NewypPre(k), Delayed2S(i)-NewzpPre(k)])...
                        <= resolution4*(norm([minNormVector02(i,1)-NewxpPre(k),minNormVector02(i,2)-NewypPre(k),minNormVector02(i,3)-NewzpPre(k)]))

                        % stable
                        stabilityVector(i) = 1;
                        stabilityVector1(i) = norm([OriginalS(i)-NewxpPre(k), Delayed1S(i)-NewypPre(k), Delayed2S(i)-NewzpPre(k)]);
                        instabilityVector1(i) = nan;

                        stabilityVector_01(i) = nan;
                        stabilityVector_01_02(i) = norm([OriginalS(i)-NewxpPre(k), Delayed1S(i)-NewypPre(k), Delayed2S(i)-NewzpPre(k)]);
                        instabilityVector_02_03(i) = nan;
                        instabilityVector_03(i) = nan;

                        stabilityVector1Tube(i) = norm([OriginalS(i)-minNormVector02(i,1), Delayed1S(i)-minNormVector02(i,2),...
                            Delayed2S(i)-minNormVector02(i,3)]);
                        instabilityVector1Tube(i) = nan;

                        instabilityVectorTubePct(i) = 0 ;

                        break;
                end
            else
            k = k + 1;
            j = j + 3;

                if norm([OriginalS(i)-NewxpPre(k), Delayed1S(i)-NewypPre(k), Delayed2S(i)-NewzpPre(k)])...
                    <= resolution4*(norm([minNormVector01(i,1)-NewxpPre(k),minNormVector01(i,2)-NewypPre(k),minNormVector01(i,3)-NewzpPre(k)]))
                    % stable 
                    stabilityVector(i) = 1;
                    stabilityVector1(i) = norm([OriginalS(i)-NewxpPre(k), Delayed1S(i)-NewypPre(k), Delayed2S(i)-NewzpPre(k)]);
                    instabilityVector1(i) = nan;

                    stabilityVector_01(i) = norm([OriginalS(i)-NewxpPre(k), Delayed1S(i)-NewypPre(k), Delayed2S(i)-NewzpPre(k)]);
                    stabilityVector_01_02(i) = nan;
                    instabilityVector_02_03(i) = nan;
                    instabilityVector_03(i) = nan;

                    stabilityVector1Tube(i) = norm([OriginalS(i)-minNormVector02(i,1), Delayed1S(i)-minNormVector02(i,2),...
                        Delayed2S(i)-minNormVector02(i,3)]);
                    instabilityVector1Tube(i) = nan;

                    instabilityVectorTubePct(i) = 0;

                elseif norm([OriginalS(i)-NewxpPre(k), Delayed1S(i)-NewypPre(k), Delayed2S(i)-NewzpPre(k)])...
                        > resolution4*(norm([minNormVector01(i,1)-NewxpPre(k),minNormVector01(i,2)-NewypPre(k),minNormVector01(i,3)-NewzpPre(k)])) && ...
                        norm([OriginalS(i)-NewxpPre(k), Delayed1S(i)-NewypPre(k), Delayed2S(i)-NewzpPre(k)])...
                        <= resolution4*(norm([minNormVector02(i,1)-NewxpPre(k),minNormVector02(i,2)-NewypPre(k),minNormVector02(i,3)-NewzpPre(k)]))
            
                    % stable
                    stabilityVector(i) = 1;
                    stabilityVector1(i) = norm([OriginalS(i)-NewxpPre(k), Delayed1S(i)-NewypPre(k), Delayed2S(i)-NewzpPre(k)]);
                    instabilityVector1(i) = nan;

                    stabilityVector_01(i) = nan;
                    stabilityVector_01_02(i) = norm([OriginalS(i)-NewxpPre(k), Delayed1S(i)-NewypPre(k), Delayed2S(i)-NewzpPre(k)]);
                    instabilityVector_02_03(i) = nan;
                    instabilityVector_03(i) = nan;

                    stabilityVector1Tube(i) = norm([OriginalS(i)-minNormVector02(i,1), Delayed1S(i)-minNormVector02(i,2),...
                        Delayed2S(i)-minNormVector02(i,3)]);
                    instabilityVector1Tube(i) = nan;

                    instabilityVectorTubePct(i) = 0 ;
                end
            end
        end
    end
end

stabilityVector_01(Idx4) = stabilityVector_01;
stabilityVector_01_02(Idx4) = stabilityVector_01_02;
instabilityVector_02_03(Idx4) = instabilityVector_02_03;
instabilityVector_03(Idx4) = instabilityVector_03;

stabilityVector(Idx4) = stabilityVector;
instabilityVectorTube(Idx4) = instabilityVectorTube;
instabilityVector(Idx4) = instabilityVector;
instabilityVectorPct(Idx4) = instabilityVectorPct;
stabilityVector1(Idx4) = stabilityVector1;
instabilityVector1(Idx4) = instabilityVector1;
stabilityVector1Tube(Idx4) = stabilityVector1Tube;
instabilityVector1Tube(Idx4) = instabilityVector1Tube;
instabilityVectorTubePct(Idx4) = instabilityVectorTubePct;

stabilityVectorSum = sum(stabilityVector(1:length(PreOriginal)));
end

