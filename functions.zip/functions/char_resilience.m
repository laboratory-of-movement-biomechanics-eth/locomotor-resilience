function [Characterisation] = char_resilience(StartPerturb,CurrentPatient_Stability, fs, instabilityVectorTubePct)
% Output:
%
% T_L - lag time before response begins
% T_P - interval from initial to maximal response
% T_S - interval from maximum response to stabilisation
% A   - maximum deviation
% P   - persisting difference from baseline level
% stability_frame - recovery frame
% A_frame         - frame where max deviation
% Lag_frame       - frame where first response starts

% Input:
%
% StartPerturb              - frame when Perturbation starts
% CurrentPatient_Stability  - seqstability of the current participant
% fs                        - samplig frequency
% instabilityVectorTubePct  - output of stability02 function -> needed to calculate max deviation

%%


%StartPerturb = 17500;

Data_after_perturb = CurrentPatient_Stability(CurrentPatient_Stability(:,2)>StartPerturb,:);
Data_after_perturb_instab = Data_after_perturb(Data_after_perturb(:,1)==0,:);

% Check where perturbation starts
Logical_status = Data_after_perturb_instab(:,4)>9;
Index_status = find(Logical_status, 1, 'first');

Lag_frame = Data_after_perturb_instab(Index_status,2); % the frame where first response starts

% Lag time before response begins
T_L = (Lag_frame - StartPerturb)/fs;

% Max Deviation
A = max(instabilityVectorTubePct(Lag_frame:end));
A_frame = find(instabilityVectorTubePct==A);

%  T_P interval from initial to maximal response
T_P = (A_frame-Lag_frame)/fs;

% T_S Interval from maximum response to stabilisation
%Data_after_perturb_instab = Data_after_perturb(Data_after_perturb(:,1)==0,:); % only instable data after max (including max dev instability)

maxdev_status = Data_after_perturb_instab(:,3) > A_frame;
Index_maxdev = find(maxdev_status, 1, 'first'); % first point where end of pert is bigger than A_frame

Data_instability = Data_after_perturb_instab(Index_maxdev:end, :);

if length(Data_instability(2:end,1))< 5 && all((Data_instability(2:end,4) <10))== true
    stability_frame = Data_instability(1,3);
else
    for i= 1:length(Data_instability)
        if length(Data_instability)-i <5 && all((Data_instability(i+1:end,4) <10))== true
            stability_frame = Data_instability(i,3);
            break
        elseif Data_instability(i+1,4) <10 && Data_instability(i+2,4)<10 && Data_instability(i+3,4)<10 ...
                && Data_instability(i+4,4)<10 && Data_instability(i+5,4)<10
            stability_frame = Data_instability(i,3);
            break
        end
    end
end

T_S = (stability_frame - A_frame)/fs;


% P persisting difference from baseline level
Data_before_perturb = CurrentPatient_Stability(CurrentPatient_Stability(:,2)<(Lag_frame),:); % including lag time

before_0 = Data_before_perturb(Data_before_perturb(:,1)==0,:);
before_1 = Data_before_perturb(Data_before_perturb(:,1)==1,:);

Data_after_recovery = CurrentPatient_Stability(CurrentPatient_Stability(:,2)>stability_frame,:);

after_0 = Data_after_recovery(Data_after_recovery(:,1)==0,:);
after_1 = Data_after_recovery(Data_after_recovery(:,1)==1,:);

P_before = sum(before_0(:,4))/sum(before_1(:,4));
P_after = sum(after_0(:,4))/sum(after_1(:,4));

P = P_after/P_before;


% saving in struct
Characterisation.T_L = T_L;
Characterisation.T_P = T_P;
Characterisation.T_S = T_S;
Characterisation.A = A;
Characterisation.P = P;
Characterisation.stability_frame = stability_frame;
Characterisation.A_frame = A_frame;
Characterisation.Lag_frame = Lag_frame;

end

