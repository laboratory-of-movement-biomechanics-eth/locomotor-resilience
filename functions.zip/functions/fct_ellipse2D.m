function [x,y] = fct_ellipse2D(a,b,x0,y0)
t=-pi:0.01:pi;
x=x0+a*cos(t);
y=y0+b*sin(t);
plot(x,y,'LineWidth',1.5,...
    'Color',[0 0 1]);
end

