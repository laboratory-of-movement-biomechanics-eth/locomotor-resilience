% Contributed authors: Ravi Deepak (depakroshanblu@gmail.com), Marc Bartholet, Caroline Heimhofer
% Affiliation: Laboratory of Movement Biomechanics, ETH Zurich, Switzerland
% Last Modified: June 2019


function [ellipse3d] = ellipseRotation(ellipse3d,rotationMatrix1,NewxpPre,NewypPre,NewzpPre,resolution2,resolution3)
% Rotation of Ellipse to align the Reference Trajectory
j = 1;
for i = 1:resolution2
    if j > (resolution2*3)
        break;
    else
        for m = 1:resolution3
            ellipse3d(m,j:j+2) = ellipse3d(m,j:j+2)  * rotationMatrix1(:,j:j+2);
            ellipse3d(m,j) = ellipse3d(m,j) + NewxpPre(i);
            ellipse3d(m,j+1) = ellipse3d(m,j+1) + NewypPre(i);
            ellipse3d(m,j+2) = ellipse3d(m,j+2) + NewzpPre(i);
        end
        j = j + 3;
    end
end
end

