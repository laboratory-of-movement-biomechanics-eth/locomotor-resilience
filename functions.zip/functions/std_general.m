function [std] = std_general(x,xref,n)
std = 0;
for i = 1:length(x)
    std = std + (x(i)-xref)^2;
end
std = sqrt(std/(n-1));
end

