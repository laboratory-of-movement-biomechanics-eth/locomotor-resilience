function [normalVector,rotationMatrix1,ellipse3d_transposed,meanMajorAxis,meanMinorAxis] = fct_ellipseCreation(resolution2,resolution3,NewxpPre,NewypPre,NewzpPre,zAxis,maxDeviation)
% Create ellipse and rotation matrices to be perpendicular to reference trajectory
%Input:
%   resolution2         - resolution for splitting phaseangles
%   resolution3         - resolution for splitting ellipses                                                       
%   NewxpPre            - Vector with Values of fitted reference trajectory
%                         for each phase angle, x-axis
%   NewypPre            - Vector with Values of fitted reference trajectory
%                         for each phase angle, y-axis
%   NewzpPre            - Vector with Values of fitted reference trajectory
%                         for each phase angle, z-axis
%   zAxis               - [0,0,1]
%   maxDeviation        - Matrix of data points with max deviation from
%                         reference trajectory for every phase angle
%                         (:,1:3) - coordinates of points
%                         (:,4)   - max deviation
%                         (:,5)   - second max deviation
% Output:
%   normalvector        - Vector with coordinates at every phaseangle on
%                         reference trajectory pointing in the direction of
%                         the next phaseangle reference trajectory point
%                         (length(phaseAngleRef), 1:3)
%   rotationMatrix1     - Rotation Matrix to allign ellipses parallel to
%                         z-axis
%   ellipse3d_transposed- Matrix with resolution3 number of ellipse points and 
%                         ellipse coordinates in the form: [ X
%                                                            Y
%                                                            Z ]
%                          (3*length(OriginalS),length(resolution3)),
%                          with max and second max deviation as axis
%   meanMajorAxis       - mean value of max deviation
%   meanMinorAxis       - mean value of second max deviation
%   
%
% Contributed authors: Ravi Deepak (depakroshanblu@gmail.com), Marc Bartholet, Caroline Heimhofer
% Affiliation: Laboratory of Movement Biomechanics, ETH Zurich, Switzerland
% Last Modified: June 2019


j=1;
normalVector = zeros(length(resolution2), 3);
rotationVector1 = zeros(length(resolution2), 4);
for i = 1:resolution2
      ellipse3d_transposed(j:j+2,:) = ellipse3D(maxDeviation(i,4),maxDeviation(i,5),...
          0,0,0,resolution3);
    if i == resolution2
        normalVector(resolution2,1) = NewxpPre(1)-NewxpPre(resolution2);
        normalVector(resolution2,2) = NewypPre(1)-NewypPre(resolution2);
        normalVector(resolution2,3) = NewzpPre(1)-NewzpPre(resolution2);
        normalVector(resolution2,1:3) = normalVector(resolution2,1:3) / norm(normalVector(resolution2,1:3));
        rotationVector1(resolution2,:) = vrrotvec([normalVector(resolution2,1),normalVector(resolution2,2),...
            normalVector(resolution2,3)],zAxis);
        rotationMatrix1(:,(resolution2*3-2):(resolution2*3)) = vrrotvec2mat(rotationVector1(resolution2,:));
        break;

    else
        normalVector(i,1) = NewxpPre(i+1)-NewxpPre(i);
        normalVector(i,2) = NewypPre(i+1)-NewypPre(i);
        normalVector(i,3) = NewzpPre(i+1)-NewzpPre(i);
        normalVector(i,1:3) = normalVector(i,1:3) / norm(normalVector(i,1:3));
        rotationVector1(i,:) = vrrotvec([normalVector(i,1),...
            normalVector(i,2),normalVector(i,3)],zAxis);
        rotationMatrix1(:,j:j+2) = vrrotvec2mat(rotationVector1(i,:));
    end
    j = j + 3;
end

meanMajorAxis = mean(maxDeviation(:,4));
meanMinorAxis = mean(maxDeviation(:,5));

end

