function [d] = planeD(n1,n2,n3,x,y,z)
d = (n1*x + n2*y + n3*z);
end

