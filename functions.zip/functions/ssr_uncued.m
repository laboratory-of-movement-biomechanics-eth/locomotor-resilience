function [XoUncued, YoUncued, ZoUncued, NewxpUncued,NewypUncued,NewzpUncued,...
    ellipse3d_01, ellipse3d_02, ellipse3d_03, normalVector] = ssr_uncued(Tau, Dim)

%this function calculates the state-space and the stability boundaries based on the normal walking
%trial.
%
% Output:
% XoUncued, YoUncued, ZoUncued              - Centroid of attractor data
% NewxpUncued,NewypUncued,NewzpUncued       - Referene trajectory
% ellipse3d_01, ellipse3d_02, ellipse3d_03  - Stability Ellipses for 1st, 2nd and 3rd std
% normalvector                              - Vector with coordinates at every phaseangle on
%                                             reference trajectory pointing in the direction of
%                                             the next phaseangle reference trajectory point
%
%
% code based on resilience_analysis_main.m file
%
% - October 2019    Caroline Heimhofer

newdata = load('NormalWalking.mat');
VD_normalWalking = newdata.VD;

VD_normalWalking.COM(:,3) = VD_normalWalking.SACR(:,3);
VD_normalWalking.COM_scalar= VD_normalWalking.COM(:,3);

Fs = VD_normalWalking.SF; % number of frames per second
remove = 5 * Fs; % remove first 5s

VD_normalWalking.COM_scalar = VD_normalWalking.COM_scalar - mean(VD_normalWalking.COM_scalar);

%% filtering

forder = 4; 
cutfreq = 5; 
srate  = 100;

beforefilter = VD_normalWalking.COM_scalar;
[b,a] = butter(forder, cutfreq / srate);
afterfilter = filtfilt(b, a, beforefilter);

VD_normalWalking.COM_scalar = afterfilter;
data = VD_normalWalking.COM_scalar(remove:end,:);

%filling nans with empty spaces
data(isnan(data)) = [];

%% State Space Reconstruction - MATLAB

[XR,tau,dim] = phaseSpaceReconstruction(data, Tau, Dim);

if tau ~= Tau || dim ~= Dim
    fprintf('something went wrong with Tau or Dim IN UNCUED WALKING!')
end

% Data of Uncued Walking
UncuedOriginal = XR(:,1); % x-axis
UncuedDelayed1 = XR(:,2); % y-axis
UncuedDelayed2 = XR(:,3); % z-axis

%% Reference Trajectory

% Centroid of Uncued Attractor
XoUncued = mean(UncuedOriginal);
YoUncued = mean(UncuedDelayed1);
ZoUncued = mean(UncuedDelayed2);

xAxis = [1,0,0];
yAxis = [0,1,0];
zAxis = [0,0,1];

% Fit Plane in Uncued-Perturbation Attractor
[fitresult4, ~] = fct_createFit1(UncuedOriginal, UncuedDelayed1, UncuedDelayed2);
normalFitresult4 = [-fitresult4.p10,-fitresult4.p01,1]; % direction of plane normal vector

% Rotation of Uncued-Perturbation Attractor to be parallel to xy-Plane
rotationVector5 = vrrotvec(zAxis,normalFitresult4);
rotationMatrix5 = vrrotvec2mat(rotationVector5);

ProjData1 = zeros(length(UncuedOriginal),3);

for i = 1:length(UncuedOriginal)
    [ProjData1(i,:)] = [UncuedOriginal(i)-XoUncued,UncuedDelayed1(i)-YoUncued,UncuedDelayed2(i)-ZoUncued] * rotationMatrix5;
end

Projxp1 = ProjData1(1:end,1); % Uncued data projected to be parallel to xy-Plane and centered around Centroid
Projyp1 = ProjData1(1:end,2);
Projzp1 = ProjData1(1:end,3);

% Calculation of Phaseangles of Uncued Attractor
phaseAngleUncued = zeros(1,length(UncuedOriginal));
for i = 1: length(UncuedOriginal)
    phaseAngleUncued(i) = atan2d(Projyp1(i),Projxp1(i));
end

phaseAngleUncued = phaseAngleUncued + 180;
phaseAngleUncued = phaseAngleUncued.';

%% Reference Trajectory

resolution1 = 0; % or 1 or 2, resolution for rounding
resolution2 = 360; % or 3600 or 36000; resolution for splitting the phaseangles
resolution3 = 50; % any integer greater 3; resolution for the ellipses

% Sort Uncued-Perturbation Data according to Phaseangles
% Round Phaseangles according to 'resolution1'
[phaseAngleUncuedRS, Idx1] = sort(phaseAngleUncued); % sorts phase angles (for every data point) and gives index
phaseAngleUncuedRS = round(phaseAngleUncuedRS,resolution1);
phaseAngleUncuedR = round(phaseAngleUncued);

UncuedOriginalS = UncuedOriginal(Idx1);
UncuedDelayed1S = UncuedDelayed1(Idx1);
UncuedDelayed2S = UncuedDelayed2(Idx1);
%phaseAngleUncuedRS: vector with phaseangle corresponding to point in UncuedoriginalS/UncuedDelayed1S/UncuedDelayed2S

% Fit Curve as Reference Trajectory
[fitresult1, gof1] = fct_createFitF8(phaseAngleUncuedRS, UncuedOriginalS);
[fitresult2, gof2] = fct_createFitF8(phaseAngleUncuedRS, UncuedDelayed1S);
[fitresult3, gof3] = fct_createFitF8(phaseAngleUncuedRS, UncuedDelayed2S);

% Reference Trajectory
phaseAngleRef = linspace(0,360-360/resolution2,resolution2); % creates a vector with resolution2 points.
phaseAngleRef = round(phaseAngleRef, resolution1);
NewxpUncued = fitresult1(phaseAngleRef);
NewypUncued = fitresult2(phaseAngleRef);
NewzpUncued = fitresult3(phaseAngleRef);

UncuedDataPhaseAngleRS = [UncuedOriginalS UncuedDelayed1S UncuedDelayed2S phaseAngleUncuedRS];
UncuedDataPhaseAngleRSstd = [UncuedOriginalS UncuedDelayed1S UncuedDelayed2S phaseAngleUncuedRS];
for i = 1:length(UncuedOriginalS)
    if  UncuedDataPhaseAngleRSstd(i,4) == resolution2
        UncuedDataPhaseAngleRSstd(i,4) = 0;
    end
end
[UncuedDataPhaseAngleRSstd(:,4), Idx] = sort(UncuedDataPhaseAngleRSstd(:,4));
UncuedDataPhaseAngleRSstd(:,3) = UncuedDataPhaseAngleRSstd(Idx,3);
UncuedDataPhaseAngleRSstd(:,2) = UncuedDataPhaseAngleRSstd(Idx,2);
UncuedDataPhaseAngleRSstd(:,1) = UncuedDataPhaseAngleRSstd(Idx,1);

[stdx,stdy,stdz] = fct_std_RefTraj(UncuedOriginalS,phaseAngleRef,UncuedDataPhaseAngleRSstd,NewxpUncued,NewypUncued,NewzpUncued,resolution2);

fitresult5 = fct_createFitP8(phaseAngleRef,stdx);
fitresult6 = fct_createFitP8(phaseAngleRef,stdy);
fitresult7 = fct_createFitP8(phaseAngleRef,stdz);

%% Creation of Ellipse Torus around Uncued Attractor

% Find maximal and second-maximal Deviation at each Phaseangle from
% Reference Trajectory and Uncued Attractor
[maxDeviation] = fct_findEllipseDimension(phaseAngleRef,UncuedDataPhaseAngleRS,UncuedOriginalS,UncuedDelayed1S,UncuedDelayed2S,...
    NewxpUncued,NewypUncued,NewzpUncued,resolution2);

for i = 1:length(phaseAngleRef) % creating the ellipses with max std as one and secondmax std as second axis
    maxDeviation(i,4) = max([stdx(i),stdy(i),stdz(i)]);
    maxDeviation(i,5) = secondmax([stdx(i),stdy(i),stdz(i)]);
end

% Creation of Ellipse and Rotation Matrix (Rotation to align the Reference
% Trajectory)
% ellipse_01 -> std
% ellipse_02 -> 2std
% ellipse_03 -> 3std
[normalVector,rotationMatrix1,ellipse3d_01_transposed,meanMajorAxis01,meanMinorAxis01] = fct_ellipseCreation(resolution2,resolution3,...
    NewxpUncued,NewypUncued,NewzpUncued,zAxis,maxDeviation);
[~,~,ellipse3d_02_transposed,meanMajorAxis02,meanMinorAxis02] = fct_ellipseCreation(resolution2,resolution3,...
    NewxpUncued,NewypUncued,NewzpUncued,zAxis,(2*maxDeviation));
[~,~,ellipse3d_03_transposed,meanMajorAxis03,meanMinorAxis03] = fct_ellipseCreation(resolution2,resolution3,...
    NewxpUncued,NewypUncued,NewzpUncued,zAxis,(3*maxDeviation));

ellipse3d_02 = ellipse3d_02_transposed.';
ellipse3d_01 = ellipse3d_01_transposed.';
ellipse3d_03 = ellipse3d_03_transposed.';

% Rotation of Ellipse to align the Reference Trajectory
[ellipse3d_02] = ellipseRotation(ellipse3d_02,rotationMatrix1,NewxpUncued,NewypUncued,NewzpUncued,resolution2,resolution3);
[ellipse3d_01] = ellipseRotation(ellipse3d_01,rotationMatrix1,NewxpUncued,NewypUncued,NewzpUncued,resolution2,resolution3);
[ellipse3d_03] = ellipseRotation(ellipse3d_03,rotationMatrix1,NewxpUncued,NewypUncued,NewzpUncued,resolution2,resolution3);

% Rotation of Ellipse around Rference Trajectory to align the maximal
% Deviations
[ellipse3d_02,maxDeviationellipse02,maxDeviationProj02,axisOrientation02] = fct_ellipseOrientation(ellipse3d_02,NewxpUncued,NewypUncued,NewzpUncued,...
    resolution2,resolution3,normalVector,maxDeviation);
[ellipse3d_01,maxDeviationellipse01,maxDeviationProj01,axisOrientation01] = fct_ellipseOrientation(ellipse3d_01,NewxpUncued,NewypUncued,NewzpUncued,...
    resolution2,resolution3,normalVector,maxDeviation);
[ellipse3d_03,maxDeviationellipse03,maxDeviationProj03,axisOrientation03] = fct_ellipseOrientation(ellipse3d_03,NewxpUncued,NewypUncued,NewzpUncued,...
    resolution2,resolution3,normalVector,maxDeviation);


end

