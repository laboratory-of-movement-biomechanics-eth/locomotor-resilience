function [maxDeviation] = fct_findEllipseDimension(phaseAngleRef,PreDataPhaseAngleRS,PreOriginalS,PreDelayed1S,PreDelayed2S,...
    NewxpPre,NewypPre,NewzpPre,resolution2)

% Find maximal and second-maximal Deviation at each Phaseangle from
% Reference Trajectory and Pre-Perturbation Attractor
%Input:
%   phaseAngleRef       - Vector with resolution3 number of phase angles
%   PreDataPhaseAngleRS - Matrix with info on each datapoint:
%                         [PreOriginalS, PreDelayedS1, PreDelayedS2, PhaseAngleRS]
%   PreOriginalS        - Vector containing pre-perturbation sorted dataset of "x-axis"
%   PreDelayed1S        - Vector containing pre-perturbation sorted dataset of "y-axis"
%   PreDelayed2S        - Vector containing pre-perturbation sorted dataset of "z-axis"
%   NewxpPre            - Vector with Values of fitted reference trajectory
%                         for each phase angle, x-axis
%   NewypPre            - Vector with Values of fitted reference trajectory
%                         for each phase angle, y-axis
%   NewzpPre            - Vector with Values of fitted reference trajectory
%                         for each phase angle, z-axis
%   resolution2         - resolution for splitting phaseangles
%
%
% Output:
%   maxDeviation       - Matrix of data points with max deviation from
%                        reference trajectory for every phase angle
%                        (:,1:3) - coordinates of points
%                        (:,4)   - max deviation
%                        (:,5)   - second max deviation
%
% Contributed authors: Ravi Deepak (depakroshanblu@gmail.com), Marc Bartholet, Caroline Heimhofer
% Affiliation: Laboratory of Movement Biomechanics, ETH Zurich, Switzerland
% Last Modified: June 2019

k = 1;
n = 1;
m = 0;
deviation = zeros(length(PreOriginalS),1);
maxDeviation = zeros(length(phaseAngleRef),5);
Idx2 = zeros(length(phaseAngleRef));
for i = 1:length(PreOriginalS)
    if phaseAngleRef(k) == PreDataPhaseAngleRS(i,4)
        deviation(i) = norm([PreOriginalS(i)-NewxpPre(k), PreDelayed1S(i)-NewypPre(k), PreDelayed2S(i)-NewzpPre(k)]);
        [maxDeviation(k,4), Idx2(k)] = max(deviation(n:i));
        
        if n<i
            maxDeviation(k,5) = secondmax(deviation(n:i));
            
        else
            maxDeviation(k,5) = maxDeviation(k,4);
        end
        
        Idx2(k) = Idx2(k) + n - 1;
        maxDeviation(k,1:3) = PreDataPhaseAngleRS(Idx2(k),1:3);
        
    elseif PreDataPhaseAngleRS(i,4) == 360
        n = i-m;
        m = m+1;
        deviation(i) = norm([PreOriginalS(i)-NewxpPre(1), PreDelayed1S(i)-NewypPre(1), PreDelayed2S(i)-NewzpPre(1)]);
        max(deviation(n:i));
        secondmax(deviation(n:i));
        
        if max(deviation(n:i)) > maxDeviation(1,4)
            [maxDeviation(1,4), Idx2(1)] = max(deviation(n:i));
            maxDeviation(1,1:3) = PreDataPhaseAngleRS(Idx2(1),1:3);
        end
        
        if secondmax(deviation(n:i)) > maxDeviation(1,5)
            maxDeviation(1,5) = secondmax(deviation(n:i));
        end
        
        Idx2(1) = Idx2(1) + n - 1;
        continue;
        
    else
        if k == resolution2
            deviation(i) = norm([PreOriginalS(i)-NewxpPre(k), PreDelayed1S(i)-NewypPre(k), PreDelayed2S(i)-NewzpPre(k)]); % Matlab says this value might be unused.
            break;
        else
            if phaseAngleRef(k+1) == PreDataPhaseAngleRS(i,4)
                k = k + 1;
                deviation(i) = norm([PreOriginalS(i)-NewxpPre(k), PreDelayed1S(i)-NewypPre(k), PreDelayed2S(i)-NewzpPre(k)]);
                n = i;
                [maxDeviation(k,4), Idx2(k)] = max(deviation(n:i));
                maxDeviation(k,5) = maxDeviation(k,4);
                Idx2(k) = Idx2(k) + n - 1;
                maxDeviation(k,1:3) = PreDataPhaseAngleRS(Idx2(k),1:3);
            else
                k = k + 1;
                for k = k:resolution2
                    if phaseAngleRef(k) == PreDataPhaseAngleRS(i,4)
                        deviation(i) = norm([PreOriginalS(i)-NewxpPre(k), PreDelayed1S(i)-NewypPre(k), PreDelayed2S(i)-NewzpPre(k)]);
                        n = i;
                        [maxDeviation(k,4), Idx2(k)] = max(deviation(n:i));
                        maxDeviation(k,5) = maxDeviation(k,4);
                        Idx2(k) = Idx2(k) + n - 1;
                        maxDeviation(k,1:3) = PreDataPhaseAngleRS(Idx2(k),1:3);
                        break;
                    else
                        maxDeviation(k,1:5) = [nan nan nan nan nan];
                    end
                end
            end
        end
    end
end
end

